from __future__ import absolute_import, division, print_function

from telnyx.telnyx_object import TelnyxObject


class NumberOrderPhoneNumber(TelnyxObject):
    OBJECT_NAME = "number_order_phone_number"
